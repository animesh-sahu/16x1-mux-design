# 16x1-mux-design
Behavioral description of 16x1 MUX using 4x1 MUX and 4x1 MUX using 2x1 
If anyone want to follow the codes of this project, I will suggest to follow the steps given below
create one 16x1 MUX (only behavioral model)
create one 4x1 MUX and instantiate them in 16x1 MUX.
create one 2x1 MUX to design 4x1 MUX.
